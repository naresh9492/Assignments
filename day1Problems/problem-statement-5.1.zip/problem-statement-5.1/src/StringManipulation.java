
public class StringManipulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           String str = "JAVA is Simple";
          
       	StringBuilder k=new StringBuilder(str);
       	k.reverse();
       	
       	System.out.println(k);
       		//String res="";
       	System.out.println(str.toUpperCase());
       	System.out.println(str.toLowerCase());
       	System.out.println(str.charAt(0));
       	System.out.println(str.length());

        
	}

}
