
public class StringHandle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "23 + 45 - ( 343 / 12 )";
        String[] s = str.split(" ", 9);
 
        for (String a : s)
            System.out.println(a);

	}

}
