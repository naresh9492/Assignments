package one;

import java.util.Scanner;

public class EvenList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner in =new Scanner(System.in);
	    System.out.println("Enter number: ");
		n=in.nextInt();
		System.out.println("Even numbers from 1 to "+n+" are:");
		for(int i=1;i<=n;i++) {
			if(i%2==0) {
				System.out.println(i+"");
				
			}
		}

	}

}
